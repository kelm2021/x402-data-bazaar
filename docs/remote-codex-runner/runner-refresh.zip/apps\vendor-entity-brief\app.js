const express = require("express");
const sellerConfig = require("./seller.config.json");
const primaryHandler = require("./handlers/primary");
const {
  bazaarResourceServerExtension,
  declareDiscoveryExtension,
} = require("@x402/extensions/bazaar");
const {
  createMetricsAttribution,
  createMetricsDashboardHandler,
  createMetricsDataHandler,
  createMetricsMiddleware,
  createMetricsStore,
  createRouteCatalog,
} = require("./metrics");

const PAY_TO = sellerConfig.payTo;
const X402_NETWORK = sellerConfig.network || "eip155:8453";
const DEFAULT_TIMEOUT_SECONDS = sellerConfig.maxTimeoutSeconds || 60;
const CANONICAL_BASE_URL =
  process.env.PUBLIC_BASE_URL || sellerConfig.baseUrl || "https://example.vercel.app";

function buildCanonicalResourceUrl(resourcePath) {
  if (!resourcePath) {
    return null;
  }

  if (resourcePath.startsWith("http://") || resourcePath.startsWith("https://")) {
    return resourcePath;
  }

  return `${CANONICAL_BASE_URL}${resourcePath}`;
}

function getCanonicalRoutePath(route) {
  return route.canonicalPath || route.resourcePath;
}

function getSellerRoutes() {
  if (Array.isArray(sellerConfig.routes) && sellerConfig.routes.length) {
    return sellerConfig.routes;
  }

  return sellerConfig.route ? [sellerConfig.route] : [];
}

function getRouteSpecificity(route) {
  const segments = String(route.routePath ?? "")
    .split("/")
    .filter(Boolean);
  const wildcardCount = segments.filter((segment) => segment === "*" || segment.startsWith(":")).length;
  const staticSegmentCount = segments.length - wildcardCount;

  return {
    staticSegmentCount,
    segmentCount: segments.length,
    wildcardCount,
  };
}

function getRegisteredRoutes() {
  return [...getSellerRoutes()].sort((left, right) => {
    const leftSpecificity = getRouteSpecificity(left);
    const rightSpecificity = getRouteSpecificity(right);

    if (leftSpecificity.staticSegmentCount !== rightSpecificity.staticSegmentCount) {
      return rightSpecificity.staticSegmentCount - leftSpecificity.staticSegmentCount;
    }

    if (leftSpecificity.segmentCount !== rightSpecificity.segmentCount) {
      return rightSpecificity.segmentCount - leftSpecificity.segmentCount;
    }

    return leftSpecificity.wildcardCount - rightSpecificity.wildcardCount;
  });
}

function inferSchemaType(value) {
  if (Array.isArray(value)) {
    return "array";
  }

  if (value === null) {
    return "string";
  }

  switch (typeof value) {
    case "number":
      return Number.isInteger(value) ? "integer" : "number";
    case "boolean":
      return "boolean";
    case "object":
      return "object";
    default:
      return "string";
  }
}

function buildQuerySchema(queryExample = {}) {
  const entries = Object.entries(queryExample);
  if (!entries.length) {
    return null;
  }

  return {
    properties: Object.fromEntries(
      entries.map(([key, value]) => [
        key,
        {
          type: inferSchemaType(value),
          description: `${key} query parameter`,
        },
      ]),
    ),
    required: entries.map(([key]) => key),
    additionalProperties: false,
  };
}

function createDiscoveryExtension(route) {
  const querySchema = buildQuerySchema(route.queryExample);

  return declareDiscoveryExtension({
    ...(route.queryExample && Object.keys(route.queryExample).length
      ? { input: route.queryExample }
      : {}),
    ...(querySchema ? { inputSchema: querySchema } : {}),
    ...(route.outputExample ? { output: { example: route.outputExample } } : {}),
  });
}

function createPricedRoute(route) {
  const normalizedPrice =
    typeof route.price === "string" && !route.price.startsWith("$")
      ? `$${route.price}`
      : route.price;

  return {
    resource: buildCanonicalResourceUrl(getCanonicalRoutePath(route)),
    accepts: {
      scheme: "exact",
      network: X402_NETWORK,
      payTo: PAY_TO,
      price: normalizedPrice,
      maxTimeoutSeconds: DEFAULT_TIMEOUT_SECONDS,
    },
    description: route.description,
    mimeType: "application/json",
    extensions: createDiscoveryExtension(route),
  };
}

function createRouteConfig() {
  return Object.fromEntries(
    getRegisteredRoutes().map((route) => [route.key, createPricedRoute(route)]),
  );
}

const routeConfig = createRouteConfig();

function getPrimaryPaymentOption(config) {
  if (!config) {
    return null;
  }

  if (Array.isArray(config.accepts)) {
    return config.accepts[0] || null;
  }

  return config.accepts || null;
}

function formatUsdPrice(price) {
  if (price == null) {
    return null;
  }

  if (typeof price === "number") {
    return `$${price} USDC`;
  }

  const normalizedPrice = price.startsWith("$") ? price : `$${price}`;
  return `${normalizedPrice} USDC`;
}

function getRoutePrice(config) {
  const paymentOption = getPrimaryPaymentOption(config);
  return formatUsdPrice(paymentOption?.price ?? null);
}

async function loadCoinbaseFacilitator(env = process.env) {
  const { createFacilitatorConfig } = await import("@coinbase/x402");
  return createFacilitatorConfig(env.CDP_API_KEY_ID, env.CDP_API_KEY_SECRET);
}

function createFacilitatorClient(facilitator) {
  if (
    facilitator &&
    typeof facilitator.verify === "function" &&
    typeof facilitator.settle === "function" &&
    typeof facilitator.getSupported === "function"
  ) {
    return facilitator;
  }

  const { HTTPFacilitatorClient } = require("@x402/core/server");
  return new HTTPFacilitatorClient(facilitator);
}

function createPaymentResourceServer(options = {}) {
  const {
    facilitator,
    logger = console,
    resourceServerClass,
    resourceServerExtension = bazaarResourceServerExtension,
    schemeFactory = () => {
      const { ExactEvmScheme } = require("@x402/evm/exact/server");
      return new ExactEvmScheme();
    },
  } = options;

  const { x402ResourceServer } = require("@x402/core/server");
  const ResourceServerClass = resourceServerClass || x402ResourceServer;
  const resourceServer = new ResourceServerClass(
    createFacilitatorClient(facilitator),
  );
  resourceServer.register(X402_NETWORK, schemeFactory());
  resourceServer.registerExtension(resourceServerExtension);

  resourceServer.onVerifyFailure(async ({ error, requirements }) => {
    logger.error(
      "x402 verify failure:",
      JSON.stringify({
        name: error?.name || "Error",
        message: error?.message || "Verification failed",
        network: requirements.network,
      }),
    );
  });

  resourceServer.onSettleFailure(async ({ error, requirements }) => {
    logger.error(
      "x402 settle failure:",
      JSON.stringify({
        name: error?.name || "Error",
        message: error?.message || "Settlement failed",
        network: requirements.network,
        errorReason: error?.errorReason || null,
        errorMessage: error?.errorMessage || null,
        transaction: error?.transaction || null,
      }),
    );
  });

  return resourceServer;
}

function createPaymentGate(options = {}) {
  const routes = options.routes ?? routeConfig;
  const facilitatorLoader = options.facilitatorLoader ?? (() => loadCoinbaseFacilitator());
  const paymentMiddlewareFactory =
    options.paymentMiddlewareFactory ??
    ((middlewareRoutes, resourceServer) => {
      const { paymentMiddleware } = require("@x402/express");
      return paymentMiddleware(middlewareRoutes, resourceServer);
    });
  const resourceServerFactory =
    options.resourceServerFactory ??
    ((factoryOptions) => createPaymentResourceServer(factoryOptions));
  const logger = options.logger ?? console;

  let paymentReady = null;

  async function getPaymentMiddleware() {
    if (!paymentReady) {
      paymentReady = Promise.resolve(facilitatorLoader())
        .then((facilitator) =>
          resourceServerFactory({
            facilitator,
            logger,
          }),
        )
        .then((resourceServer) => paymentMiddlewareFactory(routes, resourceServer));
    }

    return paymentReady;
  }

  return async function paymentGate(req, res, next) {
    try {
      if (!req.headers["payment-signature"] && req.headers["x-payment"]) {
        req.headers["payment-signature"] = req.headers["x-payment"];
      }

      const originalJson = res.json.bind(res);
      res.json = function patchedJson(body) {
        const paymentRequiredHeader = res.getHeader("PAYMENT-REQUIRED");
        const paymentResponseHeader = res.getHeader("PAYMENT-RESPONSE");
        const isEmptyObject =
          body &&
          typeof body === "object" &&
          !Array.isArray(body) &&
          Object.keys(body).length === 0;

        if (res.statusCode === 402 && paymentResponseHeader && isEmptyObject) {
          res.statusCode = 500;
          return originalJson({
            error: "Payment settlement failed",
          });
        }

        if (res.statusCode === 402 && paymentRequiredHeader && isEmptyObject) {
          const { decodePaymentRequiredHeader } = require("@x402/core/http");
          return originalJson(decodePaymentRequiredHeader(String(paymentRequiredHeader)));
        }

        return originalJson(body);
      };

      const middleware = await getPaymentMiddleware();
      return await middleware(req, res, next);
    } catch (err) {
      return res.status(500).json({
        error: "Payment middleware init failed",
        details: err.message,
      });
    }
  };
}

function getCanonicalRouteEntries(routes = routeConfig) {
  return getRegisteredRoutes().map((route) => {
    const config = routes[route.key];
    const [method, routePath] = route.key.split(" ");

    return {
      method,
      path: routePath,
      canonicalUrl: config?.resource ?? buildCanonicalResourceUrl(getCanonicalRoutePath(route)),
      price: getRoutePrice(config ?? createPricedRoute(route)),
      description: config?.description ?? route.description ?? null,
    };
  });
}

function createPaymentsMcpIntegration(routes = routeConfig) {
  const routeEntries = getCanonicalRouteEntries(routes);
  const primaryRoute = routeEntries[0] ?? null;
  const canonicalTemplateUrl =
    `${CANONICAL_BASE_URL}/api/vendor-entity-brief?name=<LEGAL_ENTITY_NAME>&country=<ISO2_COUNTRY_CODE>&minScore=90&limit=3`;

  return {
    installerPackage: "@coinbase/payments-mcp",
    installCommands: {
      codex: "npx @coinbase/payments-mcp --client codex --auto-config",
      claudeCode: "npx @coinbase/payments-mcp --client claude-code --auto-config",
      gemini: "npx @coinbase/payments-mcp --client gemini --auto-config",
    },
    primaryPrompt: primaryRoute
      ? `Use payments-mcp to pay ${primaryRoute.canonicalUrl} and return the JSON response.`
      : `Use payments-mcp to pay ${canonicalTemplateUrl} and return the JSON response.`,
    routePrompts: routeEntries.map((entry) => ({
      method: entry.method,
      path: entry.path,
      canonicalUrl: entry.canonicalUrl,
      prompt: `Use payments-mcp to pay ${entry.canonicalUrl} and return the JSON response.`,
    })),
    scenarioPrompts: [
      {
        id: "supplier-onboarding",
        title: "Supplier Onboarding Gate",
        prompt:
          `Use payments-mcp to pay ${canonicalTemplateUrl} after a restricted-party screen came back clean enough to continue. Return the JSON, then tell me whether onboarding should proceed or pause based on data.summary.recommendedAction.`,
      },
      {
        id: "cross-border-counterparty",
        title: "Cross-Border Counterparty Review",
        prompt:
          `Before approving a new cross-border vendor, use payments-mcp to pay ${canonicalTemplateUrl}. Summarize the best LEI candidate, jurisdiction fit, and whether sanctions screening requires human review.`,
      },
      {
        id: "ap-payout-review",
        title: "Accounts Payable Review",
        prompt:
          `Use payments-mcp to pay ${canonicalTemplateUrl} for the counterparty on this payout. If the response shows manualReviewRecommended or a sanctions match, tell me to pause payment and escalate.`,
      },
    ],
    shareCopy: {
      shortPost:
        "Built a vendor-entity-brief add-on at vendor-entity-brief.vercel.app for teams that need a short handoff artifact after a restricted-party screen. It resolves legal entities through GLEIF, layers in OFAC screening, and is ready to call through Coinbase Payments MCP.",
      developerDm:
        "If you are building procurement, AP, or cross-border onboarding agents, I have a live x402 vendor entity brief that combines GLEIF entity records with OFAC screening in one paid call. It works best as the follow-on step when a buyer needs a compact summary, not as the first-pass gate.",
      docsSnippet:
        "Install Coinbase Payments MCP, then call the vendor-entity-brief route through MCP when a clean screen still needs a compact handoff summary with LEI candidates, jurisdiction context, sanctions matches, and a proceed-or-pause recommendation.",
    },
  };
}

function createPaymentsMcpIntegrationHandler(routes = routeConfig) {
  const paymentsMcp = createPaymentsMcpIntegration(routes);

  return function paymentsMcpIntegrationHandler(req, res) {
    res.json({
      service: sellerConfig.serviceName,
      protocol: "x402",
      paymentsMcp,
    });
  };
}

function createHealthHandler(routes = routeConfig) {
  return function healthHandler(req, res) {
    const catalog = getCanonicalRouteEntries(routes);

    res.json({
      name: sellerConfig.serviceName,
      description: sellerConfig.serviceDescription,
      version: "1.0.0",
      endpoints: catalog.length,
      catalog,
      payment: {
        network: "Base",
        pricingDenomination: "USDC",
        protocol: "x402",
      },
      integrations: {
        paymentsMcp: createPaymentsMcpIntegration(routes),
      },
    });
  };
}

function mountPaidRoutes(target) {
  for (const route of getRegisteredRoutes()) {
    const method = route.method.toLowerCase();
    if (typeof target[method] !== "function") {
      throw new Error(`Unsupported HTTP method in route key: ${route.method}`);
    }

    target[method](route.expressPath, primaryHandler);
  }
}

function createApp(options = {}) {
  const env = options.env ?? process.env;
  const routes = options.routes ?? routeConfig;
  const metricsRouteCatalog = options.metricsRouteCatalog ?? createRouteCatalog(routes);
  const metricsAttribution =
    options.metricsAttribution ??
    createMetricsAttribution({
      env,
      sourceSalt: options.metricsSourceSalt,
    });
  const metricsStore =
    options.metricsStore ??
    createMetricsStore({
      env,
      routes,
      routeCatalog: metricsRouteCatalog,
    });
  const paymentGate = options.paymentGate ?? createPaymentGate({ ...options, routes });
  const app = express();
  app.use(express.json());
  app.set("trust proxy", 1);
  app.get("/", createHealthHandler(routes));
  app.get("/integrations/payments-mcp", createPaymentsMcpIntegrationHandler(routes));
  app.get(
    "/ops/metrics",
    createMetricsDashboardHandler({
      password: options.metricsPassword ?? env.METRICS_DASHBOARD_PASSWORD,
      attribution: metricsAttribution,
      store: metricsStore,
    }),
  );
  app.get(
    "/ops/metrics/data",
    createMetricsDataHandler({
      password: options.metricsPassword ?? env.METRICS_DASHBOARD_PASSWORD,
      attribution: metricsAttribution,
      store: metricsStore,
    }),
  );
  app.use(
    createMetricsMiddleware({
      attribution: metricsAttribution,
      logger: options.logger ?? console,
      routeCatalog: metricsRouteCatalog,
      routes,
      store: metricsStore,
    }),
  );

  const paidRouter = express.Router();
  mountPaidRoutes(paidRouter);
  app.use(paymentGate, paidRouter);

  return app;
}

module.exports = {
  PAY_TO,
  X402_NETWORK,
  createApp,
  createMetricsAttribution,
  createMetricsDashboardHandler,
  createMetricsDataHandler,
  createMetricsMiddleware,
  createMetricsStore,
  createPaymentGate,
  createPaymentResourceServer,
  createRouteCatalog,
  createRouteConfig,
  createPaymentsMcpIntegration,
  loadCoinbaseFacilitator,
  routeConfig,
  sellerConfig,
};
