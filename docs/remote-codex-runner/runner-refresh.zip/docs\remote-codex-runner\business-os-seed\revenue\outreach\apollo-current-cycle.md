# Apollo Current Cycle

Status: active

Current assignment:
- convert the lead wedge into a one-name pilot offer
- tighten Payments MCP and direct-use prompts around the pilot result
- identify where the bundle enters the buyer flow
- run follow-up against already reachable channels before sourcing new prospects
- keep one live-example ask ready for replies so a responder can move with a single counterparty name

## Lead Wedge

Lead wedge: `restricted-party-screen`
Bundle / upsell: `vendor-entity-brief`

The distribution job is to get the screen into a real buyer workflow first, then offer the brief only when it saves review time or makes handoff easier.

## 5 Concrete Buyer Workflow Targets

1. Procurement intake for a new supplier before approval.
   - Buyer job: decide whether the supplier can move forward or needs escalation.
   - Screen first, then attach the brief only if a human needs context.

2. Vendor onboarding for finance or operations.
   - Buyer job: vet a vendor before adding them to payment or onboarding systems.
   - Payments MCP fits as the default invocation for the quick gate; direct operator workflows fit when a coordinator is manually checking a ticket or email thread.

3. Payout approval for a new contractor, marketplace seller, or payee.
   - Buyer job: make sure the counterparty is safe enough to pay.
   - The screen is the first pass; the brief is the handoff artifact if the payment owner wants a summary.

4. Compliance or risk triage for a name that needs a fast first-pass check.
   - Buyer job: decide whether to stop, escalate, or continue.
   - Payments MCP fits when the user wants a one-line action from an agent; direct operator workflows fit in Slack, ticketing, or spreadsheet-based review.

5. Agentic vendor review workflows where another agent needs a cheap yes/no before doing deeper diligence.
   - Buyer job: avoid spending more time on a bad counterparty.
   - The screen acts like the default gate; the bundle is only for cases that need a compact explanation.

## Where Payments MCP Fits

Payments MCP should be the low-friction entry point when the buyer is already in an agent workflow and wants to invoke the screen immediately.

Use Payments MCP prompts like:
- `Run a quick restricted-party screen on this counterparty and return only the decision signal.`
- `Screen this vendor, then generate a short vendor entity brief if the screen is clean enough to continue.`
- `Check this counterparty for risk, and if there is a plausible match, explain the hit in plain language.`

Payments MCP is the best fit when:
- the buyer is already inside an agent shell
- the user wants a simple tool call, not a sales conversation
- the action should feel like a cheap default gate

## Where Direct Operator Workflows Fit

Direct operator workflows are the manual routes that do not depend on marketplace discovery.

Use them when the buyer is:
- working from email, Slack, a ticket, or a spreadsheet
- approving a vendor or payout by hand
- asking for a fast screen before involving a human reviewer
- not ready to wire up a tool immediately

Direct operator workflows should use short copy-paste prompts, for example:
- `Screen this counterparty before approval.`
- `If the screen is clean, give me a short brief I can forward.`
- `Tell me whether this vendor is safe enough to keep moving.`

## Fast Pilot Offer

Best next ask:

- ask the buyer for one vendor, payee, or contractor name
- return `Proceed`, `Review`, or `Pause`
- include a 3-bullet reason summary
- include the recommended next action

This turns the offer from an abstract description into a concrete workflow test.

## 3 Opening Message Drafts

1. `We built a very small counterparty screen for procurement and onboarding teams. It gives you a cheap first-pass gate before you spend time on a full review. If that would fit one of your approval flows, I can show you the 30-second version.`

2. `If your team screens new vendors, payees, or contractors before approval, this is meant to slot in as the first check. The bundle adds a short entity brief only when someone needs handoff context.`

3. `I'm reaching out because we have a low-friction screen for new counterparties that works well as a default gate in agent or operator workflows. If you want, I can run a one-name pilot and return the exact output the reviewer would see.`

## Follow-Up Copy For Reachable Routes

Subject: `One-name counterparty screen (same day)`

Body:

`Quick follow-up: if useful, send one vendor/payee name and I'll run a same-day restricted-party-screen with a clear proceed/review/pause result. If your reviewer needs context, I can add the short vendor-entity-brief.`

## Near-Term Goal

Get one real counterparty name from an already reachable route, return a same-day result, and measure whether that produces the first non-self workflow proof.

Use the repaired send-ready pack this cycle:

- `content/approved/lead-wedge-one-pager.md`
- `content/approved/reply-pack.md`
- `content/drafts/outreach-sequence.md`
