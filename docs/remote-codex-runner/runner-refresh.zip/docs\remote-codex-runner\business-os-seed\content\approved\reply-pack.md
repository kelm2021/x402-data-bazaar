# Reply Pack

Use these short replies when someone asks what this is, what to send, what the first step looks like, or what the result comes back as.

## 1. What is this?

It is a fast counterparty trust check. The lead offer is `restricted-party-screen`, which returns a quick first-pass signal so a team can decide whether to proceed, pause, or review.

If a human reviewer needs context, add the `vendor-entity-brief` bundle.

## 2. What is the easiest way to try it?

Reply with one vendor, payee, or contractor name.

I will return:

- `Proceed`, `Review`, or `Pause`
- a 3-bullet reason summary
- the recommended next action

No integration is required for the pilot. The point is to let the buyer see the exact output on a real counterparty before rollout.

## 3. What do I send you?

Send:

- the counterparty name
- any alternate spelling or legal entity name if you have it
- the workflow context if it matters, such as procurement, payout, onboarding, or review

If you only want the screen, that is enough. If you want the bundle, I can include the short brief too.

## 4. What does the result look like?

You get a simple, usable result:

- screen result: `Proceed`, `Review`, or `Pause`
- a 3-bullet reason summary
- if bundled: a short plain-English brief that explains the result and the next step

The result is meant to be handoff-ready, not a giant report.

## 5. What happens after the pilot?

If the one-name pilot saves time, move to paid usage:

- `restricted-party-screen` as the default first-pass gate
- `restricted-party-screen + vendor-entity-brief` when a reviewer needs a handoff-ready summary

## Short Replies

- "It is a fast first-pass screen for a counterparty."
- "Reply with one name and I will return proceed, review, or pause plus the next action."
- "If you need context for a human reviewer, I can add the brief."
- "The goal is a clear decision, not a long report."
