# 3-Touch Outreach Sequence

Direct operator workflow angle: fast screening first, brief second, no ceremony.

## Touch 1: Short Intro

Subject: Fast counterparty screening for your workflow

Body:
Hi, I'm reaching out because teams doing procurement, onboarding, or payout approvals usually need a quick trust gate before they spend time on a deeper review.

I built a fast `restricted-party-screen` flow for that first decision. If the workflow needs context, there is a short `vendor-entity-brief` bundle on top.

If you have one vendor, partner, or payout counterparty you are checking this week, send the name and I will show you the result format.

## Touch 2: Workflow Friction Follow-up

Subject: Where the trust check usually gets stuck

Body:
Most teams do not need a big research project. They need a fast answer they can pass to procurement, legal, or ops without restarting the workflow.

That is the gap this fits:
- screen first
- brief only if needed
- keep the approval moving

If that would help, reply with one live counterparty and I can keep the result to a simple first-pass screen.

## Touch 3: Close

Subject: Want me to run one example?

Body:
Last note from me. If you have one counterparty that is waiting on review, I can run the screen and, if useful, attach the short brief so your team has something usable right away.

Reply with one name and I'll keep it simple.
