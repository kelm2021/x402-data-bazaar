# Revenue Plan

## Mission

- Net revenue target: $1,000
- Deadline: 2026-03-31

## Current Thesis

- Start with existing assets, especially `x402-data-bazaar`.
- Current lead wedge remains trust/compliance/security because it already has a live asset and a believable buyer job.
- x402 remains a valid near-term rail, but not the entire business strategy.
- If a non-x402 path offers a faster or more believable path to cash, take it.
- The specific lead wedge is now:
  - `restricted-party-screen` as the cheap default gate
  - `vendor-entity-brief` as the modest bundle / upsell when a buyer needs handoff context

## Current Offer Shape

- `restricted-party-screen`
  - lead product
  - default use: first-pass counterparty gate
  - current pricing posture:
    - single-name screen remains low-friction
    - batch screen is now `$0.15`, not premium fantasy pricing
- `vendor-entity-brief`
  - bundle / upsell
  - default use: follow-on summary after a screen is clean enough to continue
  - current pricing posture:
    - `$0.25`
    - justified only as a compact handoff artifact, not a premium research product

## Current Execution Move

- Tighten pricing, packaging, and telemetry trust before adding more wedges.
- Prove demand through:
  - direct buyer workflows
  - Payments MCP prompts
  - non-self probes
  - first paid calls
- Do not broaden the product line until the current lead wedge has either real traction or honest falsification.

## 7-14 Day Switch Rules

### Continue Bazaar/direct lead wedge

- Keep this path if the next 7 days produce at least 3 non-self probes or 1 paid conversion and no repeated request for a handoff artifact.
- Keep it if direct buyer workflows remain the fastest believable close path.
- Keep it if the bundle is still an upsell, not a requirement.

### Move to direct-service-first

- Move here if 2 or more serious buyer conversations can close faster through a human-assisted screen than through a product flow.
- Move here if buyers want the current wedge but do not yet trust a self-serve path.
- Move here if outbound/operator follow-up is the shortest path to cash in the next 7-14 days.

### Move to bundle-led workflow

- Move here if 2 of the last 4 serious opportunities ask for context, explanation, or a reviewer-ready artifact.
- Move here if the bundle shortens approval time enough to change the close.
- Move here if the screen alone is useful, but the handoff pack is what makes the buyer say yes.

## Working Channel Order

1. Existing current assets
2. Direct buyer workflows
3. Payments MCP and other low-friction invocation surfaces
4. MCP and app-directory wrappers
5. ACP only when the work becomes job-shaped and stateful

## Kill Rules

- Kill weak pricing assumptions quickly.
- Kill channels that do not produce downstream action.
- Kill new wedge ideas that cannot explain why a buyer would pay now.
- Kill dashboard narratives that confuse observed hosts with real product count.
