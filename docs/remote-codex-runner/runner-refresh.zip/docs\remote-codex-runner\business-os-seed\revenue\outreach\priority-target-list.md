# Priority Target List

Lead wedge: `restricted-party-screen`
Bundle / upsell: `vendor-entity-brief`

Goal for this list:
- identify outside-Bazaar buyers and partners who already live inside procurement, compliance, or payout workflows
- keep the target list small enough to work this week
- use the screen first, then offer the brief only when it saves review time

## Tier 1 Real Targets From Public Sources

### Money Angle 1: Procurement And Vendor Onboarding

| Target | Who To Contact | Why It Fits | Public Source |
| --- | --- | --- | --- |
| OneCredential | Founder, product lead, procurement advisor | talks directly to procurement teams about faster supplier onboarding and due diligence | https://www.onecredential.io/procurement-teams |
| VISO TRUST | Founder, customer success lead, vendor onboarding lead | positioned around vendor onboarding and documented pre-contract due diligence | https://visotrust.com/use-cases/vendor-onboarding/ |
| Prevalent | Services lead, procurement due diligence lead, partner manager | managed procurement due diligence and vendor onboarding service model | https://stage.prevalent.net/services/procurement-due-diligence-service/ |
| Procol | Founder, implementation lead, procurement consultant | vendor onboarding and due diligence software with direct workflow fit | https://www.procol.io/vendor-onboarding/ |
| AuthBridge | Partnership lead, vendor onboarding consultant, enterprise sales lead | vendor onboarding and due diligence solution with strong workflow overlap | https://authbridge.com/solutions/vendor-onboarding/ |

### Money Angle 2: Compliance And Due Diligence Advisors

| Target | Who To Contact | Why It Fits | Public Source |
| --- | --- | --- | --- |
| Go Fractional | Compliance officer candidates, fractional CCO lead, founder | large pool of vetted compliance operators who can sell the screen as part of advisory work | https://www.gofractional.com/hire/compliance-officer |
| Arootah | Advisory lead, due diligence consultant, operations lead | sells front-to-back advisory and due diligence support | https://startup.jobs/consultant-due-diligence-investment-analyst-fractional-contract-role-arootah-6362875 |
| Fraxtional | Fractional CCO lead, compliance advisor, founder | directly markets fractional compliance leadership | https://www.fraxtional.co/blog/fractional-cco-consulting-guide |
| Axiom Law | Onboarding vendor due diligence lawyer, practice lead | can use the screen as a pre-review gate or referral tool for vendor diligence work | https://www.axiomlaw.com/skills/onboarding-vendor-due-diligence |
| UGR Consulting | Founder, fractional CCO, investigative due diligence lead | cited publicly as a compliance and due diligence-focused advisory firm | https://jake-jorgovan.com/blog/fractional-chief-compliance-officer-cco-consultants-consulting-firms |

### Money Angle 3: Finance Ops, AP, And Payout Approval

| Target | Who To Contact | Why It Fits | Public Source |
| --- | --- | --- | --- |
| Finops.Company | Fractional CFO, finance ops lead, founder | finance operations plus tax/compliance positioning; likely has vendor review and approval pain | https://finops.company/ |
| Valua Partners | Fractional CFO, finance lead, client services lead | direct finance function leadership with diligence and reporting focus | https://valuapartners.com/ |
| Coresight Consulting | Founder, fractional CFO, finance ops lead | explicit vendor cost savings and finance operations angle | https://www.coresightconsulting.com/ |
| CFO Pro Analytics | CFO advisory lead, internal controls lead, AP/process lead | speaks directly to internal controls and vendor file review patterns | https://cfoproanalytics.com/cfo-wiki/fractional-cfo/how-a-fractional-cfo-strengthens-internal-controls/ |
| PKF O'Donnell | CFO/advisory partner, accounting advisory lead | vendor onboarding and accounts payable workflow overlap | https://www.pkfod.com/wp-content/uploads/2020/07/Outsource-CFO-Session-2-7-30-2020-FINAL.pdf |

## Quickest Target List Shape For This Week

Build a 30-contact list with this ratio:
- 10 procurement / vendor onboarding operators
- 10 compliance / due diligence advisors
- 10 finance ops / AP / fractional CFO operators

For each contact, capture:
- firm
- name
- title
- LinkedIn or public profile URL
- email or contact form
- one sentence on why they fit
- one sentence on which money angle they belong to

## Exact Search Patterns

Use these searches to expand each angle fast:

### Procurement And Vendor Onboarding

Search patterns:
- `"vendor onboarding" consultant procurement LinkedIn`
- `"procurement" "vendor onboarding" consultant`
- `"supplier onboarding" due diligence consultant`
- `"vendor risk" procurement consultant`
- `site:linkedin.com/in ("procurement" OR "vendor onboarding") ("founder" OR "principal" OR "consultant")`

Qualification rules:
- they talk about vendor onboarding, procurement, or supplier due diligence publicly
- they can name a real client workflow or repeat use case
- they have a consulting or advisory motion, not just software branding
- they can plausibly forward a screen to a client this week

### Compliance And Due Diligence Advisors

Search patterns:
- `"fractional CCO" consultant`
- `"due diligence" advisory firm vendor`
- `"compliance" consultant "vendor screening"`
- `"counterparty risk" advisor`
- `site:linkedin.com/in ("compliance" OR "due diligence") ("advisor" OR "principal" OR "consultant" OR "fractional")`

Qualification rules:
- they sell judgment or review time
- they already work on vendor, payee, or counterparty checks
- they understand escalation and handoff artifacts
- they can see how the brief saves them time

### Finance Ops And AP

Search patterns:
- `"fractional CFO" "vendor onboarding"`
- `"accounts payable" consultant vendor review`
- `"finance operations" consultant vendor approval`
- `"internal controls" fractional CFO vendor`
- `site:linkedin.com/in ("AP" OR "finance operations" OR "fractional CFO") ("vendor" OR "approval" OR "controls")`

Qualification rules:
- they touch payment approval, vendor setup, or controls
- they are likely to benefit from a fast pre-payment gate
- they have enough workflow ownership to try the screen without a long sales cycle
- they can tell us whether a brief is useful for handoff

## Outreach Rules

- Lead with the screen, not the bundle.
- Ask for one real workflow to test, not a generic demo.
- Offer the bundle only after they confirm a review or handoff step.
- Favor small firms and independent operators first.
- Do not waste time on targets that only sell software without client workflow ownership unless a partnership path is obvious.

## This Week's Workable Plan

1. Pick 10 names from the procurement list, 10 from compliance, and 10 from finance ops.
2. Send a short opener to each group using the angle-specific copy.
3. Track reply quality, not just opens.
4. Move only the fastest responders into a live workflow test.
5. Promote the bundle only where it reduces review time or creates a handoff note.

## Working Assumption

If a target does not already talk about vendor onboarding, due diligence, controls, or payout approval, it is probably not worth time this week.

## Top 10 Contact-Level Prospects

These are the most promising public targets to work this week.

| Rank | Target | Title | Firm | Public Contact Method | Best Opening Angle |
| --- | --- | --- | --- | --- | --- |
| 1 | Paul Valente | Chief Customer Officer & Co-Founder | VISO TRUST | Book a meeting or use the contact page at `https://visotrust.com/company/contact/` | Compliance and due diligence advisors |
| 2 | Corentin Le Reun | Chief Executive Officer | VISO TRUST | Book a meeting or use the contact page at `https://visotrust.com/company/contact/` | Compliance and due diligence advisors |
| 3 | Ajay Trehan | Founder & Chief Executive Officer | AuthBridge | Request demo / Speak to Sales form at `https://authbridge.com/solutions/vendor-onboarding/` | Procurement and vendor onboarding |
| 4 | Raviraj Singh Ghai | Chief Sales Officer & Founding Member | AuthBridge | Request demo / Speak to Sales form at `https://authbridge.com/solutions/vendor-onboarding/` | Procurement and vendor onboarding |
| 5 | Ryan Cimo | Founder & Chief Executive Officer | Fraxtional | Contact form at `https://www.fraxtional.co/contact-us` | Compliance and due diligence advisors |
| 6 | Cloe Guidry-Reed | Chief Executive Officer | OneCredential | Contact form at `https://www.onecredential.io/contact-us` | Procurement and vendor onboarding |
| 7 | Sonja Crystal Williams | Head of Marketing & Customer Success | OneCredential | Contact form and support email at `https://www.onecredential.io/contact-us` | Procurement and vendor onboarding |
| 8 | Gaurav Baheti | Founder & Chief Executive Officer | Procol | Request demo / contact sales at `https://www.procol.io/request-demo/` | Procurement and vendor onboarding |
| 9 | Salvatore Tirabassi | Managing Director | CFO Pro Analytics | Contact email `info@cfoproanalytics.com` via `https://cfoproanalytics.com/contact-us/` | Finance ops and AP |
| 10 | Chris Lazarte | Partner | Valua Partners | Contact email `info@valuapartners.com` or contact form at `https://valuapartners.com/contact/` | Finance ops and AP |

## Contact-Level Notes

- Prioritize the first reply from the person most likely to own the workflow, even if that is not the biggest title.
- If a contact is clearly a sales leader or customer leader, use them as the fastest route into the account.
- If the contact page is the only public method, use it and keep the message short.
- If a firm has a published support or demo email, use that only as a fallback.
- Keep each outreach message aligned to the opening angle listed above.
