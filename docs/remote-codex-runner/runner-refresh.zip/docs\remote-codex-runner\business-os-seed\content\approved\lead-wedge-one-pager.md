# Counterparty Trust Checks for Fast-moving Teams

One-line pitch: screen a counterparty fast, then add a short brief only when the workflow needs handoff-ready context.

## Who This Is For

- Procurement teams that need a quick answer before approving a supplier.
- Compliance and risk teams that want a lightweight first pass before human review.
- Operations and payouts teams that need to screen counterparties without slowing the workflow.
- Agents and automations that need a simple trust gate before continuing.

## What It Does

`restricted-party-screen` gives you a fast screening signal on a counterparty so a team can decide whether to proceed, pause, or review.

It is built for the first decision, not the final memo. When the workflow needs a handoff-ready summary, add `vendor-entity-brief` as the bundle upsell.

## Lead Offer

Use `restricted-party-screen` when you need:

- a quick yes/no or proceed/review signal
- a low-friction default gate
- a simple check before spending more time on diligence
- something cheap enough to use as the default first step

## Bundle Upsell

Use `restricted-party-screen` plus `vendor-entity-brief` when the result needs to be handed to a human reviewer, procurement teammate, or another agent.

The bundle adds a short written summary so the screening result is easier to share, justify, and act on.

## Workflow Examples

1. A procurement agent screens a new supplier before sending the request to legal. If the screen is clean, it moves forward. If not, it stops for review.
2. A payout workflow checks a new counterparty before releasing funds. If the screen is clean enough, it continues. If the team needs context, it upgrades to the brief.
3. A vendor onboarding flow runs the screen first and uses the bundle only when the buyer wants a compact summary for the approval record.

## Fast Pilot

Reply with one vendor, payee, or contractor name and I will return, in the same thread:

- `Proceed`, `Review`, or `Pause`
- a 3-bullet reason summary
- the recommended next action

No integration is required for this first pass.

This is a workflow gate, not a legal or compliance opinion. If the format saves time, move to paid usage with `restricted-party-screen` alone or the `restricted-party-screen + vendor-entity-brief` bundle.

## CTA

Open to a one-name pilot this week so you can see the exact output before rollout?

## What To Send

- counterparty or legal entity name
- workflow context, such as vendor onboarding, procurement approval, payout review, or compliance triage
- any alternate spelling if the name is likely to vary across systems

## What You Get Back

- a first-pass result: proceed, review, or pause
- a 3-bullet reason summary
- the recommended next action
- if bundled, a compact handoff-ready brief for the next reviewer

## Reply-Ready Language

- "It is a fast first-pass screen for a counterparty."
- "Reply with one name and I will return proceed, review, or pause plus the next action."
- "If you need context for a human reviewer, add the brief."
- "The goal is to keep the approval moving without pretending the screen is more than it is."
