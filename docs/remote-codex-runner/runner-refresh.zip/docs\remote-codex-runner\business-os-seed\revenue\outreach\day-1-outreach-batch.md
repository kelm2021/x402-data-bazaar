# Day 1 Outreach Batch

Goal: create the first wave of real buyer conversations around the lead wedge instead of adding more internal analysis.

Lead wedge: `restricted-party-screen`
Bundle / upsell: `vendor-entity-brief`

Use this file to send the first 10 targeted notes. Keep the ask small: one live counterparty, one workflow, or one approval step that needs a faster first-pass trust check.

## Send Order

1. VISO TRUST
2. AuthBridge
3. OneCredential
4. Fraxtional
5. Procol
6. CFO Pro Analytics
7. Valua Partners

## Message Rules

- Lead with the screen, not the bundle.
- Ask for one live example, not a demo meeting.
- Mention the brief only as the follow-on handoff artifact.
- Keep the message short enough to survive a contact form.

## Ready-To-Send Targets

### 1. Paul Valente, VISO TRUST

- Role: Chief Customer Officer & Co-Founder
- Contact: `https://visotrust.com/company/contact/`
- Angle: vendor onboarding and due-diligence workflow compression

Message:

```text
Hi Paul, I built a very small counterparty screen for vendor onboarding teams that need a fast first-pass trust gate before a deeper review.

It is meant for the first decision, not the full memo. If the workflow needs something handoff-ready after the screen, there is a short brief on top.

If your team has one supplier or counterparty waiting on review this week, send the name and I can show you the result format.
```

### 2. Corentin Le Reun, VISO TRUST

- Role: Chief Executive Officer
- Contact: `https://visotrust.com/company/contact/`
- Angle: vendor onboarding signal before full diligence

Message:

```text
Hi Corentin, I am working on a lightweight counterparty screen that fits ahead of deeper vendor due diligence.

The idea is simple: screen first, then add a short brief only when someone needs handoff context. It is built for teams that want a cheap default gate before they spend more review time.

If useful, I can run one live example against a counterparty your team is already considering.
```

### 3. Ajay Trehan, AuthBridge

- Role: Founder & Chief Executive Officer
- Contact: `https://authbridge.com/solutions/vendor-onboarding/`
- Angle: supplier onboarding and trust gating

Message:

```text
Hi Ajay, I built a small restricted-party screen for teams handling vendor onboarding and approval.

It is designed to answer the first workflow question quickly: keep moving, pause, or escalate. If someone needs a compact explanation after that, there is a short brief as the bundle.

If that fits any supplier onboarding flow you touch, I can share a live example with one name.
```

### 4. Raviraj Singh Ghai, AuthBridge

- Role: Chief Sales Officer & Founding Member
- Contact: `https://authbridge.com/solutions/vendor-onboarding/`
- Angle: workflow fit for onboarding and due diligence teams

Message:

```text
Hi Raviraj, I built a low-friction first-pass screen for new counterparties in onboarding and due-diligence workflows.

It is intentionally cheap and simple so teams can use it as a default gate before asking for a bigger review. The brief only comes in when someone needs a handoff note.

If you want, I can send the short version or run one live example with a real counterparty.
```

### 5. Ryan Cimo, Fraxtional

- Role: Founder & Chief Executive Officer
- Contact: `https://www.fraxtional.co/contact-us`
- Angle: fractional compliance teams need a fast triage tool

Message:

```text
Hi Ryan, I built a small counterparty screen that fits the first step in compliance or onboarding review: enough signal to decide whether something should move forward or get escalated.

The value is speed. The brief is only there if a client or teammate needs a compact summary after the screen.

If one of your operators has a vendor or payee waiting on review, I can run one example and keep it very simple.
```

### 6. Cloe Guidry-Reed, OneCredential

- Role: Chief Executive Officer
- Contact: `https://www.onecredential.io/contact-us`
- Angle: procurement onboarding with a fast trust gate

Message:

```text
Hi Cloe, I built a fast first-pass counterparty screen for procurement and onboarding teams that need a quick trust signal before they spend more review time.

It is not meant to replace a deeper diligence workflow. It is meant to keep the workflow moving until a real stop signal appears. When needed, there is a short brief for handoff.

If useful, I can show the result format against one live counterparty.
```

### 7. Sonja Crystal Williams, OneCredential

- Role: Head of Marketing & Customer Success
- Contact: `https://www.onecredential.io/contact-us`
- Angle: customer-facing workflow acceleration

Message:

```text
Hi Sonja, I built a very small restricted-party screen for onboarding workflows that need a cheap first gate before a deeper review starts.

The reason I am reaching out is that the workflow is simple enough to fit into customer success or onboarding operations without much setup. If someone needs context after the screen, the brief adds that second layer.

If you want, I can send the 30-second version or run one live example.
```

### 8. Gaurav Baheti, Procol

- Role: Founder & Chief Executive Officer
- Contact: `https://www.procol.io/request-demo/`
- Angle: supplier onboarding triage

Message:

```text
Hi Gaurav, I built a lightweight counterparty screen for supplier onboarding workflows that need a fast first-pass signal before a team spends more diligence effort.

The screen is the lead product. The brief is only used when a teammate needs something handoff-ready after the first check.

If this fits any procurement workflow you see, I can run one live example using a real supplier name.
```

### 9. Salvatore Tirabassi, CFO Pro Analytics

- Role: Managing Director
- Contact: `info@cfoproanalytics.com`
- Angle: internal controls and payment approval

Message:

```text
Hi Salvatore, I built a small counterparty screen for finance teams that need a quick first-pass trust check before approving a new vendor, payee, or contractor.

The point is not to replace a deeper controls review. The point is to create a cheap gate that tells the team whether to continue, pause, or escalate. If needed, there is a short brief after the screen.

If you have one live example this week, I can run it and share the result format.
```

### 10. Chris Lazarte, Valua Partners

- Role: Partner
- Contact: `info@valuapartners.com`
- Angle: fractional finance workflow and approval support

Message:

```text
Hi Chris, I built a low-friction counterparty screen for teams that need a quick first-pass signal before spending more time on vendor or payout review.

It works best as a default trust gate. The short brief only gets added when a client or teammate needs a handoff-ready explanation.

If one of your clients has a live counterparty review step, I can show the result on one real name.
```

## Success Condition

For this first batch, success is not revenue yet. Success is any of:

- one reply asking for more detail
- one request to run a live example
- one request for pricing or a sample workflow
- one inbound signal that the screen fits a real buyer workflow
